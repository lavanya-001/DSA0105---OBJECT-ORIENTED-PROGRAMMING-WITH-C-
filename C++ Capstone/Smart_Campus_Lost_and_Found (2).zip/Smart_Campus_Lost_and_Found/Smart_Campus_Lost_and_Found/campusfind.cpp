#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Item {
    int id;
    string name;
    string category;
    string location;
    string type;
    string status;
};

vector<Item> items;
int nextId = 1;

void reportItem(string type) {
    Item item;

    item.id = nextId++;
    item.type = type;

    cin.ignore();

    cout << "\nEnter Item Name: ";
    getline(cin, item.name);

    cout << "Enter Category: ";
    getline(cin, item.category);

    cout << "Enter Location: ";
    getline(cin, item.location);

    item.status = "Open";

    items.push_back(item);

    cout << "\nItem reported successfully!";
    cout << "\nYour Item ID: " << item.id << endl;
}

void displayItems() {
    if (items.empty()) {
        cout << "\nNo items available.\n";
        return;
    }

    cout << "\n========== CAMPUS ITEMS ==========\n";

    for (const Item &item : items) {
        cout << "\nItem ID: " << item.id;
        cout << "\nName: " << item.name;
        cout << "\nCategory: " << item.category;
        cout << "\nLocation: " << item.location;
        cout << "\nType: " << item.type;
        cout << "\nStatus: " << item.status;
        cout << "\n--------------------------------\n";
    }
}

void searchItem() {
    string searchName;
    bool found = false;

    cin.ignore();

    cout << "\nEnter item name to search: ";
    getline(cin, searchName);

    for (const Item &item : items) {
        if (item.name == searchName) {
            cout << "\nItem Found!";
            cout << "\nItem ID: " << item.id;
            cout << "\nName: " << item.name;
            cout << "\nCategory: " << item.category;
            cout << "\nLocation: " << item.location;
            cout << "\nType: " << item.type << endl;

            found = true;
        }
    }

    if (!found) {
        cout << "\nNo matching item found.\n";
    }
}

void markReturned() {
    int id;

    cout << "\nEnter Item ID: ";
    cin >> id;

    for (Item &item : items) {
        if (item.id == id) {
            item.status = "Returned";
            cout << "\nItem successfully marked as returned!\n";
            return;
        }
    }

    cout << "\nInvalid Item ID.\n";
}

int main() {
    int choice;

    do {
        cout << "\n================================";
        cout << "\n       CAMPUSFIND SYSTEM";
        cout << "\n================================";
        cout << "\n1. Report Lost Item";
        cout << "\n2. Report Found Item";
        cout << "\n3. Search Item";
        cout << "\n4. Display All Items";
        cout << "\n5. Mark Item as Returned";
        cout << "\n6. Exit";
        cout << "\n================================";
        cout << "\nEnter your choice: ";

        cin >> choice;

        switch (choice) {
            case 1:
                reportItem("Lost");
                break;

            case 2:
                reportItem("Found");
                break;

            case 3:
                searchItem();
                break;

            case 4:
                displayItems();
                break;

            case 5:
                markReturned();
                break;

            case 6:
                cout << "\nThank you for using CampusFind!\n";
                break;

            default:
                cout << "\nInvalid choice. Try again.\n";
        }

    } while (choice != 6);

    return 0;
}