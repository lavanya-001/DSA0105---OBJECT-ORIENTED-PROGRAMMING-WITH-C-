from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import uuid

app = Flask(__name__)

app.secret_key = "smart_campus_lost_found_secret"

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

DATABASE = os.path.join(BASE_DIR, "campus.db")

UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# Check whether the user is logged in
def login_required():
    return "user_id" in session


# Check allowed image formats
def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


# Initialize database
def init_db():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            college_id TEXT UNIQUE NOT NULL,
            mobile TEXT NOT NULL,
            role TEXT NOT NULL,
            password TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            item_name TEXT NOT NULL,
            category TEXT,
            description TEXT,
            location TEXT,
            date TEXT,
            item_type TEXT,
            image TEXT,
            status TEXT DEFAULT 'Open'
        )
    """)

    conn.commit()
    conn.close()


# Database connection
def get_db():

    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row

    return conn


# Home page
@app.route("/")
def home():

    return render_template("index.html")


# Registration
@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form["name"].strip()
        college_id = request.form["college_id"].strip()
        mobile = request.form["mobile"].strip()
        role = request.form["role"]

        password = generate_password_hash(
            request.form["password"]
        )

        conn = get_db()

        try:

            conn.execute(
                """
                INSERT INTO users
                (name, college_id, mobile, role, password)
                VALUES (?, ?, ?, ?, ?)
                """,
                (name, college_id, mobile, role, password)
            )

            conn.commit()

            flash("Registration successful! Please log in.")

            return redirect(url_for("login"))

        except sqlite3.IntegrityError:

            flash("This college ID is already registered.")

        finally:

            conn.close()

    return render_template("register.html")


# Login
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        college_id = request.form["college_id"].strip()
        password = request.form["password"]

        conn = get_db()

        user = conn.execute(
            "SELECT * FROM users WHERE college_id = ?",
            (college_id,)
        ).fetchone()

        conn.close()

        if user and check_password_hash(
            user["password"], password
        ):

            session.clear()

            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]

            return redirect(url_for("dashboard"))

        flash("Invalid college ID or password.")

    return render_template("login.html")


# Dashboard
@app.route("/dashboard")
def dashboard():

    if not login_required():
        return redirect(url_for("login"))

    conn = get_db()

    lost_count = conn.execute(
        "SELECT COUNT(*) FROM items WHERE item_type='Lost'"
    ).fetchone()[0]

    found_count = conn.execute(
        "SELECT COUNT(*) FROM items WHERE item_type='Found'"
    ).fetchone()[0]

    recent_items = conn.execute(
        "SELECT * FROM items ORDER BY id DESC LIMIT 5"
    ).fetchall()

    conn.close()

    return render_template(
        "dashboard.html",
        lost_count=lost_count,
        found_count=found_count,
        recent_items=recent_items
    )


# Save lost or found report
def save_item(item_type):

    if not login_required():
        return redirect(url_for("login"))

    if request.method == "POST":

        item_name = request.form["item_name"].strip()

        category = request.form.get("category", "")
        description = request.form.get("description", "")
        location = request.form.get("location", "")
        date = request.form.get("date", "")

        image = request.files.get("image")

        image_name = ""

        # Save uploaded image
        if image and image.filename:

            if not allowed_file(image.filename):

                flash("Please upload a valid image file.")

                return redirect(request.url)

            original_name = secure_filename(image.filename)

            extension = original_name.rsplit(".", 1)[1].lower()

            image_name = f"{uuid.uuid4().hex}.{extension}"

            image.save(
                os.path.join(UPLOAD_FOLDER, image_name)
            )

        # Save report in database
        conn = get_db()

        conn.execute(
            """
            INSERT INTO items
            (user_id, item_name, category, description,
             location, date, item_type, image)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session["user_id"],
                item_name,
                category,
                description,
                location,
                date,
                item_type,
                image_name
            )
        )

        conn.commit()
        conn.close()

        flash("Your item report has been submitted!")

        return redirect(url_for("my_reports"))

    template = (
        "report_lost.html"
        if item_type == "Lost"
        else "report_found.html"
    )

    return render_template(template)


# Report lost item
@app.route("/report-lost", methods=["GET", "POST"])
def report_lost():

    return save_item("Lost")


# Report found item
@app.route("/report-found", methods=["GET", "POST"])
def report_found():

    return save_item("Found")


# Display uploaded images
@app.route("/uploads/<filename>")
def uploaded_file(filename):

    return send_from_directory(
        UPLOAD_FOLDER,
        filename
    )


# Search items
@app.route("/search")
def search():

    if not login_required():
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()

    conn = get_db()

    items = conn.execute(
        """
        SELECT * FROM items
        WHERE item_name LIKE ?
        OR category LIKE ?
        OR location LIKE ?
        ORDER BY id DESC
        """,
        (
            f"%{keyword}%",
            f"%{keyword}%",
            f"%{keyword}%"
        )
    ).fetchall()

    conn.close()

    return render_template(
        "search.html",
        items=items
    )


# Possible lost and found matches
@app.route("/matches")
def matches():

    if not login_required():
        return redirect(url_for("login"))

    conn = get_db()

    lost_items = conn.execute(
        """
        SELECT * FROM items
        WHERE item_type='Lost' AND status='Open'
        """
    ).fetchall()

    found_items = conn.execute(
        """
        SELECT * FROM items
        WHERE item_type='Found' AND status='Open'
        """
    ).fetchall()

    possible_matches = []

    for lost in lost_items:

        for found in found_items:

            if lost["item_name"].strip().lower() == found["item_name"].strip().lower():

                possible_matches.append((lost, found))

    conn.close()

    return render_template(
        "matches.html",
        matches=possible_matches
    )


# Item details
@app.route("/item/<int:item_id>")
def item_details(item_id):

    if not login_required():
        return redirect(url_for("login"))

    conn = get_db()

    item = conn.execute(
        """
        SELECT items.*, users.name, users.mobile
        FROM items
        JOIN users ON items.user_id = users.id
        WHERE items.id = ?
        """,
        (item_id,)
    ).fetchone()

    conn.close()

    if item is None:
        return "Item not found", 404

    return render_template(
        "item_details.html",
        item=item
    )


# My reports
@app.route("/my-reports")
def my_reports():

    if not login_required():
        return redirect(url_for("login"))

    conn = get_db()

    reports = conn.execute(
        """
        SELECT * FROM items
        WHERE user_id = ?
        ORDER BY id DESC
        """,
        (session["user_id"],)
    ).fetchall()

    conn.close()

    return render_template(
        "my_reports.html",
        reports=reports
    )


# About project
@app.route("/about")
def about():

    return render_template("about.html")


# Logout
@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("home"))


# Handle oversized uploads
@app.errorhandler(413)
def file_too_large(error):

    flash("Image is too large. Maximum allowed size is 5 MB.")

    return redirect(url_for("dashboard"))


# Run application
if __name__ == "__main__":

    init_db()

    app.run(debug=True)