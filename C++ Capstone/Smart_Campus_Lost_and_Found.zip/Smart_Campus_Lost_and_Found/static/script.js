document.addEventListener("DOMContentLoaded", function () {

    // Preview uploaded item image
    const imageInput = document.querySelector('input[type="file"]');

    if (imageInput) {
        imageInput.addEventListener("change", function () {

            const file = this.files[0];

            if (file) {
                const reader = new FileReader();

                reader.onload = function (event) {

                    let preview = document.getElementById("image-preview");

                    if (!preview) {
                        preview = document.createElement("img");
                        preview.id = "image-preview";

                        preview.style.maxWidth = "220px";
                        preview.style.maxHeight = "180px";
                        preview.style.marginTop = "15px";
                        preview.style.borderRadius = "10px";

                        imageInput.parentNode.appendChild(preview);
                    }

                    preview.src = event.target.result;
                };

                reader.readAsDataURL(file);
            }
        });
    }

    // Confirm before submitting a report
    const reportForms = document.querySelectorAll(
        'form[enctype="multipart/form-data"]'
    );

    reportForms.forEach(function (form) {

        form.addEventListener("submit", function (event) {

            const confirmSubmit = confirm(
                "Are you sure you want to submit this item report?"
            );

            if (!confirmSubmit) {
                event.preventDefault();
            }
        });

    });

});